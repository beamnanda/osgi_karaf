# Apache Camel Karaf Examples

[Apache Camel](http://camel.apache.org/) is a powerful open source integration framework based on known
Enterprise Integration Patterns with powerful bean integration.

### Introduction

This project provides examples for Apache Camel Karaf.

package com.redhat.consulting.fusequickstarts.springboot.restconsumer.restjavadsl;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class RestJavaDslApplication {

    public static void main(String[] args) {
        SpringApplication.run(RestJavaDslApplication.class, args);
    }

}

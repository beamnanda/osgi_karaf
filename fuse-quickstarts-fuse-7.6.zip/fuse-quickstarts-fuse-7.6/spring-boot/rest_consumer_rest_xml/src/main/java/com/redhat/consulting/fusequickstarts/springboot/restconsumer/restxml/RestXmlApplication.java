package com.redhat.consulting.fusequickstarts.springboot.restconsumer.restxml;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class RestXmlApplication {

    public static void main(String[] args) {
        SpringApplication.run(RestXmlApplication.class, args);
    }

}

package com.redhat.consulting.fusequickstarts.eap.jaxrs.service;

import javax.ws.rs.ApplicationPath;
import javax.ws.rs.core.Application;

@ApplicationPath("/rest")
public class RestConfig extends Application{

}

package com.redhat.consulting.fusequickstarts.karaf.osgi_service.service.api;

public interface IHelloService {
    public String sayMessage();
    public String sayHello(String pName);
}

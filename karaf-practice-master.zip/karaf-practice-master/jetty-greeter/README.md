# jetty-greeter

Webservice that does nothing interesting.

```shell
feature:install camel-jetty
```

```shell
bundle:install -s mvn:com.asodc.karaf/jetty-greeter/1.0-SNAPSHOT
```

http://localhost:8080/greeter

# camel-design

Just trying out various ways of organising Camel route definitions.

Unsure of how exception handling and MEPs work in these cases.

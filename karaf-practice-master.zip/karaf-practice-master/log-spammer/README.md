# log-spammer

Spams the logs with a configurable message.

## Installation

Install to local Maven repository, then in Karaf shell:
```shell
bundle:install -s mvn:com.asodc.karaf/log-spammer/1.0-SNAPSHOT
```
